SELECT DISTINCT c_address
FROM customer
WHERE c_nationkey = 6

