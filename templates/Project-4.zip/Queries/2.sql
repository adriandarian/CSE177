SELECT SUM(c_acctbal), c_name 
FROM customer
GROUP BY c_name

