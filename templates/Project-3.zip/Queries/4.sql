SELECT c_name, c_address, c_acctbal 
FROM customer 
WHERE c_name='Customer#000070919'

