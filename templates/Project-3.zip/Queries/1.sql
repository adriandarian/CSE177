SELECT n_nationkey, n_name
FROM nation 
WHERE n_regionkey=1

