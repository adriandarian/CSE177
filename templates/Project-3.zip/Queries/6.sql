SELECT l_orderkey 
FROM lineitem
WHERE l_quantity>30.0

